<?php
$conn=mysqli_connect("localhost","root","","ajax_crud");
$select_students="select * from students";
$result_students=mysqli_query($conn,$select_students);
$result_array=[];
if(mysqli_num_rows($result_students)>0)
{
   foreach($result_students as $row)
   {
     array_push($result_array,$row);
   }
   header('Content-type:application/json');
   echo json_encode($result_array);
}
else
{
  echo $return="<h4>No Record Found</h4>";
}
?>