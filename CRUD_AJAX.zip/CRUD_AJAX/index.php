<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AJAX CRUD</title>

            <!-- Popper JS -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

            <!----Font Awesome-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <!-------- jQuery library------------->
    <script src="https://code.jquery.com/jquery-3.7.0.js"></script>

            <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
            <!----------Bootstrap CDN---------------->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>

</head>
<body>
    <!---------Display data from the database------------>
    <div class="container"> 
        <h1 class="text-center text-primary my-5">AJAX CRUD Application</h1>
        <h2 class="text-danger">All Records</h2>
        <table class="table table-bordered table-striped my-4 text-center">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Password</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody class="studentData"></tbody>
        </table>
    </div>   
 
    <!-------------AJAX Code---------------->
    <script>
        $(document).ready(function()
        {
            getData();
        });
        function getData()
        {
           $.ajax({
            type: "GET",
            url: "ajax-crud/fetch.php",
            success: function (response) {
                // console.log(response);
                $.each(response, function (key, value) { 
                  //   console.log(value['first_name']);
                });
            }
           });     
        }
        
    </script>

</body>
</html>