<?php
include('connection.php');
$name=$_POST['name'];
echo $name;
exit();
if(isset($_POST['name']) && isset($_POST['email']) && isset($_POST['password']))
{
   $query="insert into `crud_table` (user_Name,user_email,user_password) values('$name','$email','$password')";
   mysqli_query($conn,$query);
}

?>